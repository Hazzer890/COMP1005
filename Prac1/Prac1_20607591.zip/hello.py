#
# hello.py: Print out greetings in various languages
#

print('Hello')
print("G'day")
print('Bula')
print("Kia ora")
